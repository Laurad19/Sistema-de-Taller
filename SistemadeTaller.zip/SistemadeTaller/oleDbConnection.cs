﻿namespace SistemadeTaller
{
    internal class oleDbConnection
    {
        private string v;

        public oleDbConnection(string v)
        {
            this.v = v;
        }
    }
}